#include <stdio.h>

int main(void) {

	char c = 'A';
	
	putchar(c);

	return 0;
}


